Implemented using forms C# (VS 2013) and sql server (2014).

In sql server:
1- Server name = "LENOVO\SQL2014"
2- Create new database name = "Restaurant_System"
3- Execute the "Script.txt" file.

In Visual Studio (2013):
Open the project in visual studio.

1-Select view from the main menu, then select SQL Server Object Explorer, right click in the SQL server and connect to the server.

2-For running the test:
	-In Solution Explorer select "Testing" solution and right click and then select "Set as StartUp Project".
	-Add "OrangeLab Task" as reference.
	Select "Project" from the main menu, then select "Add Reference",choose "Solution" then select "OrangeLab Task".
	
3-For running the project:
	-In Solution Explorer select "OrangeLab Task" solution and right click and then select "Set as StartUp Project".


NOTE: if there a problem with the server name, you can modify it in the code.
"OrangLab Task" solution, go to "Connection" class, then update the "ordb" string with the new server name in the class constructor.