Implemented using forms C# (VS 2013) and Oracle database (11g).

In oracle database (11g):
1- Should create a connection in oracle where: 
	User Id = "scott"
	Password = "tiger"

2- Run the "Script.txt" file.

In Visual Studio (2013):
Open the project in visual studio.

For running the test:
-In Solution Explorer select "Testing" solution and right click and then select "Set as StartUp Project".
-Add "Oracle.Database.Extensions.dll" as reference.	
	Select "Project" from the main menu, then select "Add Reference",choose "Browes" then go to "Oracle.Database.Extensions.dll" path and add it.
-Add "OrangeLab Task" as reference.
	Select "Project" from the main menu, then select "Add Reference",choose "Solution" then select "OrangeLab Task".
	
For running the project:
-In Solution Explorer select "OrangeLab Task" solution and right click and then select "Set as StartUp Project".
-Add "Oracle.Database.Extensions.dll" as reference.	